<input type="hidden" id="kd_order" name="kd_order" value="{{ $order->no_order }}">
<input type="hidden" id="id_dis" name="id_dis" value="{{ $order->id_distribusi }}">
<input type="hidden" id="orang" name="orang" value="{{ $order->orang }}  ">
<input type="hidden" id="meja" name="meja" value="{{ $order->id_meja }}  ">
<input type="hidden" id="warna" name="warna" value="{{ $order->warna }}  ">
<div class="row">
    <div class="col-lg-4">
        <label for="">Menu</label>
        <select name="id_harga[]" class="form-control id_harga id_harga1 select2bs4" detail="1" required>
            <option value="">-Pilih Menu-</option>
            <?php foreach ($menu as $m) : ?>
            <option value="{{ $m->id_harga }}">
                {{ $m->nm_menu }}
            </option>
            <?php endforeach ?>
        </select>
    </div>
    <div class="col-lg-2">
        <label for="">Qty</label>
        <input type="number" name="qty[]" value="1" min="1" class="form-control">
    </div>
    <div class="col-lg-2">
        <label for="">Harga</label>
        <input type="text" name="harga[]" class="form-control harga harga1" detail="1" readonly>
    </div>
    <div class="col-lg-3">
        <label for="">Request</label>
        <input type="text" name="req[]" class="form-control">
    </div>
</div>


